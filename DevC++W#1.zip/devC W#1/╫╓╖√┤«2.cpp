int main() {

	char str1[] = "hello world";
	cout << str1 << endl;
    
	system("pause");

	return 0;
}

int main() {

	string str = "hello world";
	cout << str << endl;
	
	system("pause");

	return 0;
}
C++�����ַ��� 
