int main() {

	char str1[] = "hello world";
	cout << str1 << endl;
    
	system("pause");

	return 0;
}

